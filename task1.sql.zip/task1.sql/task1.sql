SELECT m.staff_id, m.first_name, m.last_name, m.store_id, c.revenue
FROM (
    SELECT m.staff_id, m.store_id, SUM(c.amount) AS revenue
    FROM payment c
    JOIN staff m ON c.staff_id = m.staff_id
    WHERE EXTRACT(YEAR FROM c.payment_date) = 2017
    GROUP BY m.staff_id, m.store_id
) c


JOIN staff m USING (staff_id)
WHERE (c.store_id, c.revenue) IN (
    SELECT store_id, MAX(revenue) AS max_revenue
    FROM (
        SELECT m.staff_id, m.store_id, SUM(c.amount) AS revenue
        FROM payment c
        JOIN staff m ON c.staff_id = m.staff_id
        WHERE EXTRACT(YEAR FROM c.payment_date) = 2017
        GROUP BY m.staff_id, m.store_id
    ) sub
    GROUP BY store_id
)
ORDER BY m.store_id;
WITH Top5RentedMovies AS (
  SELECT
    m.movie_id,
    m.title,
    COUNT(c.payment_id) AS rental_count
  FROM
    movie m
    JOIN inventory i ON m.movie_id = i.movie_id
    JOIN rental r ON i.inventory_id = r.inventory_id
    JOIN payment c ON r.rental_id = p.rental_id
  GROUP BY
    m.movie_id, m.title
  ORDER BY
    rental_count DESC
  LIMIT 5
)

SELECT
  trm.movie_id,
  trm.title AS movie_title,
  CASE
    WHEN m.rating = 'PG-13' THEN '13+'
    WHEN m.rating = 'NC-17' THEN '18+'
    WHEN m.rating = 'R' THEN '17+'
    WHEN m.rating = 'PG' THEN '7+'
    WHEN m.rating = 'G' THEN 'All ages'
    ELSE 'Not specified'
  END AS appropriate_age_rating
FROM
  Top5RentedMovies trm
  JOIN movie f ON trm.movie_id = m.movie_id
ORDER BY
  trm.movie_id;

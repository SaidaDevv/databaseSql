SELECT
  p.first_name,
  p.last_name,
  p.actor_id,
  MAX(o.release_year) - MIN(o.release_year) AS inactive_period

FROM
  actor p
  JOIN film_actor fa ON p.actor_id = fa.actor_id
  JOIN film o ON fa.film_id = f.film_id

GROUP BY
  p.actor_id
  
ORDER BY
  inactive_period 
  limit 1;
